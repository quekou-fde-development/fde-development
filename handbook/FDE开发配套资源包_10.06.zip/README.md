---
title: FDE 开发配套资源包
version: "10.09.2"
status: 发布版
---

# FDE 开发配套资源包

## 使用顺序

先读同版手册，再按任务解压 `packages/`。`inputs/通用调研输入文档_10.06.md` 是供项目填写的调研空表；先填已知内容，未知项留下来源与补料线索。

## 小包目录

| 文件 | 用途与状态 |
|---|---|
| `packages/01-development-design_10.06.zip` | 九份写作参照；王磊八份与第 3 份数据结构 |
| `packages/02-meta-skill_3.10.1.zip` | Meta Skill 文件快照，目标宿主验证按项目完成 |
| `packages/03-meta-orchestrator_10.06.zip` | 设计方法参考，完整编译实现不在本包 |
| `packages/04-meta-agent_10.06.zip` | 参数化制作候选包，目标宿主尚待验收 |
| `packages/05-workbench-app-development_10.06.zip` | Workbench Skill 与完整 references |
| `packages/06-quekou-frontend_1.0.0.zip` | 前端共享原件，核对目标 React 与浏览器兼容性 |
| `00-fde-flow/` | 上层 FDE 流程图原件 |
| `07-specialist-tools/README.md` | OctoPlanner、老马 drawings、SKU Radar 的输入、产物与网址 |

## 其他入口

Meta Spec 10.09.1 已在[工具目录](https://github.com/quekou-fde-development/fde-development/tree/main/tools/meta-spec/)发布，下载包从该入口取得；本总包保留以上六个小包。已知问题与验收范围见 Skill 包内 `verification.json`，项目生成的架构继续交总架构师审核。

开发计划模板见 `inputs/开发计划模板_10.08.md`。先在 Arcubase 登记母项目和场景，按“母项目编码＋客户名称＋期号”新建内部开发仓库，并建立场景文件夹。再用 Meta Workflow 形成 A（业务流程、整体架构图及 graph），再用 Meta Spec 形成 B（九份 spec），最后填写具体开发时间、方式与工具、预计 token、依赖和验收安排。由项目经理将开发架构（A+B）和开发计划放入对应场景目录，作为两部分邮件异步送审。GitHub 只承担内部开发交互，客户背景、调研、业务解释和项目推进记录保存在 Arcubase。反馈使用仓库的 [GitHub Issue 入口](https://github.com/quekou-fde-development/fde-development/issues/new?template=feedback.yml)。

送审时每个场景只需 `workflow/`、`design/` 和 `plan/`，README 提供关联与阅读导航。审核通过后先建立 `releases/` 并开发，形成可测试版本后再建立 `tests/`，记录对应版本的测试、缺陷和复测。技术复核与发布批准完成后上线并交接；实现目录按实际工具和框架组织，不统一要求建立 `src/`。

## 核验与使用

本版复用已整理的五个工具包快照，保留各包的依赖与验证状态；候选和方法参考按所标范围使用。`manifest.json` 与 `SHA256SUMS.txt` 记录文件和包内哈希。任何包的存在或文件校验通过都不代表目标项目生产验收完成。
