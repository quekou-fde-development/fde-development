---
title: FDE 开发配套资源包
version: "10.06.4"
status: 交接版
---

# FDE 开发配套资源包

## 加载链（上下游）

**上游**：随附手册 `FDE开发技术手册_10.06.md §附录 配套资源包` — 按任务选择工具时读取。

## 使用顺序

先读同版手册，再按任务解压 `packages/`。`inputs/通用调研输入文档_10.06.md` 是已有调研空表的原样副本；先填已知内容，未知项留下来源与补料线索。

## 小包目录

| 文件 | 用途与状态 |
|---|---|
| `packages/01-development-design_10.06.zip` | 九份写作参照；王磊八份与第 3 份数据结构 |
| `packages/02-meta-skill_3.10.1.zip` | Meta Skill 文件快照，目标宿主验证按项目完成 |
| `packages/03-meta-orchestrator_10.06.zip` | 设计方法参考，完整编译实现不在本包 |
| `packages/04-meta-agent_10.06.zip` | 参数化制作候选包，目标宿主尚待验收 |
| `packages/05-workbench-app-development_10.06.zip` | Workbench Skill 与完整 references |
| `packages/06-quekou-frontend_1.0.0.zip` | 前端共享原件，核对目标 React 与浏览器兼容性 |
| `00-fde-flow/` | 上层 FDE 流程图原件 |
| `07-specialist-tools/README.md` | OctoPlanner、老马 drawings、SKU Radar 的输入、产物与网址 |

## 后补入口

Meta Architecture Development：开发中，预留 `tools/skills/meta-architecture-development/`，首批不包含执行包；九参考已提供。开发计划标准化以后补齐。反馈先用统一仓库 GitHub Issue；数字员工自动协同挂起。

## 核验与使用

本版复用已整理的五个工具包快照，保留各包的依赖与验证状态；候选和方法参考按所标范围使用。`manifest.json` 与 `SHA256SUMS.txt` 记录文件和包内哈希。任何包的存在或文件校验通过都不代表目标项目生产验收完成。
