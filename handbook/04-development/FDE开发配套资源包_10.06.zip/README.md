---
title: FDE 开发配套资源包
version: "11.05"
status: 发布版
---

# FDE 开发配套资源包

## 使用顺序

先读同版手册，再按任务解压 `packages/`。`inputs/通用调研输入文档_10.06.md` 是供项目填写的调研空表；先填已知内容，未知项留下来源与补料线索。

## 小包目录

| 文件 | 用途与状态 |
|---|---|
| `packages/01-development-design_10.06.zip` | 九份写作参照；王磊八份与第 3 份数据结构 |
| `packages/02-meta-skill_3.10.1.zip` | Meta Skill 文件快照，目标宿主验证按项目完成 |
| `packages/03-meta-orchestrator_10.06.zip` | 设计方法参考，完整编译实现不在本包 |
| `packages/04-meta-agent_10.06.zip` | 参数化制作候选包，目标宿主尚待验收 |
| `packages/05-workbench-app-development_10.06.zip` | Workbench Skill 与完整 references |
| `packages/06-quekou-frontend_1.0.0.zip` | 前端共享原件，核对目标 React 与浏览器兼容性 |
| `00-fde-flow/` | 总流程图（2026年10月3日袁黎明原版基础上修订，11.05），原样保留 |
| `07-specialist-tools/README.md` | OctoPlanner、老马 drawings、SKU Radar 的输入、产物与网址 |

## 其他入口

Meta Spec 11.05 已在[工具目录](https://github.com/quekou-fde-development/fde-development/tree/main/tools/meta-spec/)发布，下载包从该入口取得；本总包保留以上六个小包。已知问题与验收范围见 Skill 包内 `verification.json`，项目生成的架构继续交总架构师审核。

开发计划模板见 `inputs/开发计划模板_10.08.md`。先在Arcubase登记母项目和场景，建立对应私有GitHub仓库与场景文件夹。先形成客户分析A（含ER图；有工作台需求时加原型），按四问填架构手册，与范围报价（可选）、开发计划一次送审，总架构师整体判断商业可行性、技术可行性与一致性；审核通过后由 FDE 以冻结版架构手册与客户分析A为输入，用 Meta Spec 自行撰写九份 spec（技术架构 B），不送审。

客户背景、调研、客户分析A、方案、沟通和签字原件保存在知识库「FDE全链」对应项目；Arcubase／Work OS保存项目结构、进展、状态及文件链接；GitHub保存A的同版引用与来源链接、开发方案B、计划、实现与技术记录。手册和工具反馈使用仓库的[GitHub Issue入口](https://github.com/quekou-fde-development/fde-development/issues/new?template=feedback.yml)。

开发审核送审时每个场景准备 `workflow/` 和 `plan/`，有工作台需求时另加 `prototype/`；`design/` 在审核通过后建立。README 提供关联与阅读导航。整体审核通过并落实启动与开工条件后先建立 `releases/` 并开发，形成可测试版本后再建立 `tests/`，记录对应版本的测试、缺陷和复测。技术复核与发布批准完成后上线并交接；实现目录按实际工具和框架组织，不统一要求建立 `src/`。

## 核验与使用

本版复用已整理的六个工具包快照，保留各包的依赖与验证状态；候选和方法参考按所标范围使用。`manifest.json` 与 `SHA256SUMS.txt` 记录文件和包内哈希。任何包的存在或文件校验通过都不代表目标项目生产验收完成。
